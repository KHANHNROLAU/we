import lib.*;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Random;
import cost.*;
import SenMess.*;
//tzumpkk
//kdkdifkckdn

public class Client {
    public static void main(String[] args) {
    try {
    ISession session = (new Session(COST.ip, COST.port)).setSend(new MessageSend()).start();
    ISession session1 = (new Session(COST.ip, COST.port)).setSend(new MessageSend()).start();
    Controller.Login(session , COST.username , COST.password);
    Controller.Login(session1 , COST.username , COST.password);
    Controller.CreatePl(session);
    Controller.CreatePl(session1);
    Controller.Npcs(session);
    Controller.Npcs(session1);
    Controller.Mobs(session);
    Controller.Mobs(session1);
      Message msg; 
      while(true){ 
      Controller.Capsule(session);
      Controller.Capsule(session1);
         try {
   Thread.sleep(5000);
   } catch (InterruptedException e) {
   }
      }
 
            } catch (IOException e) {
         System.err.println("Kết nối thất bại");
         System.exit(0);
      }
        }
}
