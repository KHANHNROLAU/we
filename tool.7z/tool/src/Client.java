import lib.*;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Random;
import cost.*;
import SenMess.*;
//tzumpkk
//kdkdifkckdn

public class Client {
 public static String chat = "Bú lồn hạ vy địt nát lồn ";
    public static void main(String[] args) {
    try {
    ISession session = (new Session(COST.ip, COST.port)).setSend(new MessageSend()).start();
    Controller.Login(session , COST.username , COST.password);
    Controller.CreatePl(session);
    Controller.Npcs(session);
    Controller.Mobs(session);
      Message msg; 
      while(true){ 
      Controller.Capsule(session);
         try {
   Thread.sleep(500);
   } catch (InterruptedException e) {
   }
      }
 
            } catch (IOException e) {
         System.err.println("Kết nối thất bại");
         System.exit(0);
      }
        }
}
