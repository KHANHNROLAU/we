package npc;

public class Npc {
     public static int[] Type = new int[]{1, 0, 1 , 0 , 2 , -1 , -1 , -1 , -1 , -1}; // 0 là không open npc 1 là open npc 2 là tap cần click 2 lần -1 mua nhiều item trong 1 npc
     public static int[] idNpc = new int[]{0, -1 , 7 , -1 , 21 , 21 , 21 , 21 , 21 , 21}; // id npc open
     public static int[] TabNpc = new int[]{0, -1 , 0 , -1 , 0 , 0 , 0 , 0 , 0 , 0}; // id tab của npc
     public static int[] TabNpc1 = new int[]{0, -1 , 0 , -1 , 0 , 0 , 0 , 0 , 0 , 0}; // id tab 2 của npc
     public static int[] Shot1 = new int[]{-1, -1 , 1 , -1 , 1 , 1 , 1 , 1 , 1 , 1}; // id 1 của shop item 
     public static int[] Shot2 = new int[]{-1, -1 , 194 , -1 , 672 , 671 , 213 , 215 , 217 , 214}; // id 2 của shop item 
     public static int[] Shot3 = new int[]{-1, -1, 0 , -1 , 0 , 0 , 0 , 0 , 0 , 0}; // id 3 số lượng
     public static int[] locationX = new int[]{263, 502, 244 , 10 , 624 , 624 , 624 , 624 , 624 , 624}; // vị trí x di chuyển đến
     public static int[] locationY = new int[]{336, 336, 432 , 432 , 408 , 408 ,408 , 408 , 408 , 408}; // vị trí y di chuyển đến 
 }