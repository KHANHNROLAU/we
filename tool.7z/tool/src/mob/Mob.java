package mob;

 public class Mob {
    public static int[] Type = new int[]{0 , 0 , 1 , 1}; // 0 là chỉ di chuyển 1 là đánh
    public static int[] locationX = new int[]{1420 , 1230 , 332 , 531}; // vị trí x di chuyển đến
     public static int[] locationY = new int[]{432 , 432 , 384 , 408}; 
     public static int[] MobId = new int[]{-1 , -1 , 1 , 1}; 
     public static int[] SotPem = new int[]{-1 , -1 , 1000 , 1000}; 
 }