package SenMess;

import lib.*;
import cost.*;
import npc.*;
import mob.*;
import java.io.IOException;
import java.util.Random;

 public class Controller {
    public static void Login(ISession s , String username , String password) {
    try {
      Message msg = new Message(-29);
      msg.writeByte((byte) 0);
      msg.writeUTF(username);
      msg.writeUTF(password);
      msg.writeUTF(COST.version);
      s.sendMessage(msg);
      msg.cleanup(); 
        } catch (IOException e) {
         System.err.println("Kết nối thất bại");
         System.exit(0);
      }
    }
    public static void CreatePl(ISession s) {
    try {
      Message msg = new Message(-28);
      msg.writeByte((byte) 2);
      msg.writeUTF("gosgg" + new Random().nextInt(10000));
      msg.writeByte((byte) 0);
      msg.writeByte((byte) 64);
      s.sendMessage(msg);
      msg.cleanup(); 
        } catch (IOException e) {
      }
    } 
    public static void location(ISession s , int x , int y ) {
      try {
             Message msg = new Message(-7);
             msg.writeByte((byte) 0);
             msg.writeShort((short) x);
             msg.writeShort((short) y);
             s.sendMessage(msg);
             msg.cleanup();
      } catch (IOException e) {
      }
    }
    public static void waypoints(ISession s) {    
      Message msg = new Message(-23);
      s.sendMessage(msg);
      msg.cleanup();
    }
    public static void openNpc(ISession s ,  int id) {  
    try {
      Message msg = new Message(33);
      msg.writeShort((short) id);
      s.sendMessage(msg);
      msg.cleanup();
       } catch (IOException e) {
     }
   }
     public static void openTabNpc(ISession s ,  int id , int tab) {  
    try {
      Message msg = new Message(32);
      msg.writeShort((short) id);
      msg.writeByte((byte) tab);
      s.sendMessage(msg);
      msg.cleanup();
       } catch (IOException e) {
     }
   }
   public static void BuyItemShop(ISession s ,  int Shot1 , int Shot2 , int Shot3) {  
    try {
      Message msg = new Message(6);
      msg.writeByte((byte) Shot1);
      msg.writeShort((short) Shot2);
      msg.writeShort((short) Shot3);
      s.sendMessage(msg);
      msg.cleanup();
       } catch (IOException e) {
     }
   }
   
      public static void attackMob(ISession s ,  int MobId) {  
    try {
      Message msg = new Message(54);
      msg.writeByte((byte) MobId);
      s.sendMessage(msg);
      msg.cleanup();
       } catch (IOException e) {
     }
   }
   
   public static void hoiSinh(ISession s) {  
      Message msg = new Message(-16);
      s.sendMessage(msg);
      msg.cleanup();
   }
   
   public static void Chat(ISession s , String chat) {
   try {
     Message msg = new Message(44);
     msg.writeUTF(chat);
     s.sendMessage(msg);
     msg.cleanup();  
       } catch (IOException e) {
     }
   }
   
    public static void Npcs(ISession s) {
    int i = 0;
       for(int idType : Npc.Type){
         int locationX = Npc.locationX[i];
         int locationY = Npc.locationY[i];
         int IdNpc = Npc.idNpc[i];
         int TabNpc = Npc.TabNpc[i];
         int TabNpc1 = Npc.TabNpc1[i];
         int Shot1 = Npc.Shot1[i];
         int Shot2 = Npc.Shot2[i];
         int Shot3 = Npc.Shot3[i];
         if(idType != -1){
         location(s , locationX , locationY);
         waypoints(s);
         }else{
         BuyItemShop(s , Shot1 , Shot2 , Shot3);
         }
         if(idType == 3){
         }
         if(idType == 1){
         openNpc(s , IdNpc);
         openTabNpc(s , IdNpc , TabNpc);
         BuyItemShop(s , Shot1 , Shot2 , Shot3);
         }
         if(idType == 2){
         openNpc(s , IdNpc);
         openTabNpc(s , IdNpc , TabNpc);
         openTabNpc(s , IdNpc , TabNpc1);
         BuyItemShop(s , Shot1 , Shot2 , Shot3);
         }
         i ++;        
      }
        System.out.println("Đã mua hiết những item yêu cầu bây giờ sẽ đánh quái");
    }
    public static void Mobs(ISession s) {
    int i = 0;
       for(int Type : Mob.Type){
       int locationX = Mob.locationX[i];
       int locationY = Mob.locationY[i];
       int SotPem = Mob.SotPem[i];
       int MobId = Mob.MobId[i];
        if(Type == 0){
        location(s , locationX , locationY);
        waypoints(s);
        }
        if(Type == 1){
         for(int ii = 0; ii <= SotPem ; ii ++){
           location(s , locationX , locationY);
           attackMob(s , MobId);
         }
        }
       i ++;
       }
       System.out.println("Hoàn thành đánh quái");
    }
    public static void Capsule(ISession session) {
          new Thread(()->{
     while(true){
     try{
     location(session , new Random().nextInt(2000) , 384);
  
     Chat(session , COST.chat[new Random().nextInt(COST.chat.length)]);
     
     hoiSinh(session);
     
     
     Message msg = new Message(-43);
     msg.writeByte((byte) 0);
     msg.writeByte((byte) 1);
     msg.writeByte((byte) 1);// vị trí item
     session.sendMessage(msg);
     msg.cleanup();
     
     msg = new Message(-91);
     msg.writeByte((byte) new Random().nextInt(12));
     session.sendMessage(msg);
     msg.cleanup();
          } catch (IOException e) {
          }
        }
   }).start();
    }
    
    
 }