package lib;

import java.io.IOException;
import java.net.Socket;
import java.net.InetAddress;
import java.io.DataInputStream;
import java.io.DataOutputStream;

public class Session implements ISession {
   private Socket socket;
   private boolean connected;
   private Sender sender;
   private Thread tSender;
   public static int port;
   public static InetAddress ipAddress; 
   public static DataInputStream putstream;
   public Session(String host, int port) throws IOException {
      (this.socket = new Socket(host, port)).setSendBufferSize(1048576);
      this.socket.setReceiveBufferSize(1048576);
      this.connected = true;
      this.port = this.socket.getLocalPort();
      this.ipAddress = this.socket.getInetAddress();
      this.putstream = new DataInputStream(this.socket.getInputStream());
      this.tSender = new Thread(this.sender != null ? this.sender.setSocket(this.socket) : (this.sender = new Sender(this, this.socket)));
   }

   public void sendMessage(Message msg) {
      if (this.isConnected()) {
         this.sender.sendMessage(msg);
      }

   }


   public ISession setSend(IMessageSend collect) {
      this.sender.setSend(collect);
      return this;
   }

   public ISession startSend() {
      this.tSender.start();
      return this;
   }

   public void disconnect() {
      System.err.println("Mất kết nối..............");
      this.connected = false;
      if (this.sender != null) {
         this.sender.close();
      }

      if (this.socket != null) {
         try {
            this.socket.close();
         } catch (IOException var2) {
         }
      }

      this.dispose();
   }

   public void dispose() {
      if (this.sender != null) {
         this.sender.dispose();
      }

      this.socket = null;
      this.sender = null;
      this.tSender = null;
   }

   public void doSendMessage(Message msg) throws Exception {
      this.sender.doSendMessage(msg);
   }

   public ISession start() {
      this.tSender.start();
      return this;
   }

   public boolean isConnected() {
      return this.connected;
   }
}
