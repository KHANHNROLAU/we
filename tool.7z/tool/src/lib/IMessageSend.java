package lib;

import java.io.DataOutputStream;

public interface IMessageSend {
   void doSendMessage(ISession var1, DataOutputStream var2, Message var3) throws Exception;
}
