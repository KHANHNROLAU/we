package lib;

public interface ISession {
   ISession setSend(IMessageSend var1);

   ISession startSend();

   ISession start();

   boolean isConnected();

   void sendMessage(Message var1);

   void doSendMessage(Message var1) throws Exception;

   void disconnect();

   void dispose();
}
