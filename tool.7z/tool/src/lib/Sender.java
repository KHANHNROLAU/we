package lib;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;

public final class Sender implements Runnable {
   private ISession session;
   private ArrayList<Message> messages;
   private DataOutputStream dos;
   private IMessageSend send;

   public Sender(ISession session, Socket socket) {
      try {
         this.session = session;
         this.messages = new ArrayList();
         this.setSocket(socket);
      } catch (Exception var4) {
      }

   }

   public Sender setSocket(Socket socket) {
      try {
         this.dos = new DataOutputStream(socket.getOutputStream());
      } catch (IOException var3) {
      }

      return this;
   }

   public void run() {
      while(this.session != null && this.session.isConnected()) {
         try {
            while(!this.messages.isEmpty()) {
               Message message = (Message)this.messages.remove(0);
               if (message != null) {
                  this.doSendMessage(message);
               }
            }

            Thread.sleep(1L);
         } catch (Exception var2) {
         }
      }

   }

   public synchronized void doSendMessage(Message message) throws Exception {
      this.send.doSendMessage(this.session, this.dos, message);
   }

   public synchronized void sendMessage(Message msg) {
      if (this.session.isConnected()) {
         this.messages.add(msg);
      }

   }

   public void setSend(IMessageSend sendCollect) {
      this.send = sendCollect;
   }

   public void close() {
      if (this.messages != null) {
         this.messages.clear();
      }

      if (this.dos != null) {
         try {
            this.dos.close();
         } catch (IOException var2) {
         }
      }

   }

   public void dispose() {
      this.session = null;
      this.messages = null;
      this.send = null;
      this.dos = null;
   }
}
