package lib;

import java.io.DataOutputStream;
import java.io.IOException;

public class MessageSend implements IMessageSend {
   public void doSendMessage(ISession session, DataOutputStream dos, Message msg) throws Exception {
      try {
         byte[] data = msg.getData();
         dos.writeByte(msg.command);
         if (data != null) {
            dos.writeShort(data.length);
            dos.write(data);
         } else {
            dos.writeShort(0);
         }

         dos.flush();
         msg.cleanup();
      } catch (IOException var5) {
         session.disconnect();
      }

   }
}
