package lib;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class Message implements IMessage {
   public byte command;
   private ByteArrayOutputStream os;
   private DataOutputStream dos;

   public Message(int command) {
      this((byte)command);
   }

   public Message(byte command) {
      this.command = command;
      this.os = new ByteArrayOutputStream();
      this.dos = new DataOutputStream(this.os);
   }

   public DataOutputStream writer() {
      return this.dos;
   }

   public byte[] getData() {
      return this.os.toByteArray();
   }

   public void cleanup() {
      try {
         if (this.os != null) {
            this.os.close();
         }

         if (this.dos != null) {
            this.dos.close();
         }
      } catch (IOException var2) {
      }

   }

   public void dispose() {
      this.cleanup();
      this.dos = null;
      this.os = null;
   }

   public void write(byte[] b) throws IOException {
      this.writer().write(b);
   }

   public void write(int b) throws IOException {
      this.writer().write(b);
   }

   public void write(byte[] b, int off, int len) throws IOException {
      this.writer().write(b, off, len);
   }

   public void writeBoolean(boolean v) throws IOException {
      this.writer().writeBoolean(v);
   }

   public void writeByte(int v) throws IOException {
      this.writer().writeByte(v);
   }

   public void writeBytes(String s) throws IOException {
      this.writer().writeBytes(s);
   }

   public void writeChar(int v) throws IOException {
      this.writer().writeChar(v);
   }

   public void writeChars(String s) throws IOException {
      this.writer().writeChars(s);
   }

   public void writeDouble(double v) throws IOException {
      this.writer().writeDouble(v);
   }

   public void writeFloat(float v) throws IOException {
      this.writer().writeFloat(v);
   }

   public void writeInt(int v) throws IOException {
      this.writer().writeInt(v);
   }

   public void writeLong(long v) throws IOException {
      this.writer().writeLong(v);
   }

   public void writeShort(int v) throws IOException {
      this.writer().writeShort(v);
   }

   public void writeUTF(String str) throws IOException {
      this.writer().writeUTF(str);
   }
}
