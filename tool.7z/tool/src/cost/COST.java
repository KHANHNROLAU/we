package cost;

public class COST {
  public static String username = "hack1150";
  public static String password = "hack1150";
  public static String username1 = "ciccjcjcjc";
  public static String password1 = "ciccjcjcjc";
  public static String version = "2.4.0";
  public static String ip = "14.225.219.205";
  public static int port = 14445;
  //public static String chat = "Bú lồn hạ vy địt nát lồn ";
  public static String[] chat = new String[]{ "Game lồn ",  "game ngu như chó",  "Địt mẹ game lồn "};
}