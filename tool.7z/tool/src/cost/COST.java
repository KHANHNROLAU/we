package cost;

public class COST {
  public static String username = "123456";
  public static String password = "123456";
  public static String version = "2.4.0";
  public static String ip = "103.77.246.54";
  public static int port = 14445;
  //public static String chat = "Bú lồn hạ vy địt nát lồn ";
  public static String[] chat = new String[]{ "Game lồn ",  "game ngu như chó",  "Địt mẹ game lồn "};
}
